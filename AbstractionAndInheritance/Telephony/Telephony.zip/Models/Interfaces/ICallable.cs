﻿

namespace Telephony.Models.Interfaces;

    public interface ICallable
    {
        string Call(string phoneNumber);
    }

