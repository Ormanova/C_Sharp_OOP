﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingSpree.Models
{
    public class Product
    {
        private string name;
        private decimal cost;

        public Product(string name, decimal cost)
        {
            this.Name = name;
            this.Cost = cost;
        }

        public string Name 
        {
            get => name;
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentNullException($"{nameof(this.Name)} cannot be empty");
                }
                name = value;
            }
        }
        public decimal Cost 
        {
            get => cost; 
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException($"{nameof(this.Cost)} cannot be negative");
                }
                cost = value;
            }
        }
        public override string ToString() => Name;
        
    }
}
