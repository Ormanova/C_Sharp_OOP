﻿
namespace VehiclesExtension.IO.Interfaces
{
    public interface IReader
    {
        // връща метод
        string ReadLne();
    }
}
