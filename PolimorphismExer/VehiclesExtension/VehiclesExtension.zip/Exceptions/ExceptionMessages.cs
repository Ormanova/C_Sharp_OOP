﻿

namespace VehiclesExtension.Exceptions
{
    //в този статичен клас се съхраняват всички цонстанти от тип стринг, които се връщат като съобщение като се хвърли грешка.
    public static class ExceptionMessages
    {
        public const string InsufficientFuelExceptionMessage = "{0} needs refueling";
    }
}
